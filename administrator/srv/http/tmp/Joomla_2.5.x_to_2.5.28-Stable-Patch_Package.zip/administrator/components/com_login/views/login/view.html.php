<?php
/**
 * @copyright	Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License, see LICENSE.php
 */

defined('_JEXEC') or die;

/**
 * HTML View class for the Login component
 *
 * @package		Joomla.Administrator
 * @subpackage	com_login
 * @since		1.6
 */
class LoginViewLogin extends JViewLegacy
{
}
